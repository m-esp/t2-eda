/*
 Class ListOfRegion
*/

namespace image {
	class ListOfRegion{
	private:		
	public:		
	};
}

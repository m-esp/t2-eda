/*
 Class ListOfPoint2D
*/

namespace image {
	class ListOfPoint2D{
	private:		
	public:		
	};
}

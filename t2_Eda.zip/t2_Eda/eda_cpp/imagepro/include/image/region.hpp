#ifndef REGION_HPP
#define REGION_HPP

#include <vector>
#include <utility>
#include <iostream>

namespace image {

    struct Region {
        int id;  
        int size;  
        std::vector<std::pair<int, int>> points; 

        void showRegion(int width, int height) const {
    // Encuentra los límites de la región
    int min_row = height, max_row = 0, min_col = width, max_col = 0;
    for (const auto& point : points) {
        if (point.first < min_row) min_row = point.first;
        if (point.first > max_row) max_row = point.first;
        if (point.second < min_col) min_col = point.second;
        if (point.second > max_col) max_col = point.second;
    }

    // Ajustar el tamaño de la visualización a los límites de la región
    std::cout << "Región ID: " << id << " con tamaño: " << size << std::endl;
    for (int i = min_row; i <= max_row; ++i) {
        for (int j = min_col; j <= max_col; ++j) {
            if (std::find(points.begin(), points.end(), std::make_pair(i, j)) != points.end()) {
                std::cout << '1';
            } else {
                std::cout << '0';
            }
        }
        std::cout << std::endl;
    }
}




    };

}  

#endif  

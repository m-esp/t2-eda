/* implementation of the class ListOfRegion
 */
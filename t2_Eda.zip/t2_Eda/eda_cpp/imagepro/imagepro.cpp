#include "image/image.hpp"
#include "image/region.hpp"
#include <iostream>
#include <locale>
#include <string>
#include <map>
#include <sstream>
#include <algorithm> 

int main(int nargs, char** vargs) {
    std::setlocale(LC_ALL, "en_US.UTF-8");

    std::map<std::string, image::Image*> images;  // Mapa para almacenar las imágenes cargadas
    std::string command;

    std::cout << "Bienvenido a ImagePro" << std::endl;

    while (true) {
        std::cout << ">> ";
        std::getline(std::cin, command);

        std::transform(command.begin(), command.end(), command.begin(), ::tolower);
        command.erase(0, command.find_first_not_of(" \t"));
        command.erase(command.find_last_not_of(" \t") + 1);

        if (command.empty()) {
            std::cout << "Comando no reconocido." << std::endl;
            continue;
        }

        // Comando para salir
        if (command == "exit") {
            std::cout << "Saliendo del programa..." << std::endl;
            break;
        }

        // Dividir el comando en palabras
        std::istringstream ss(command);
        std::string first_word, second_word, third_word;
        ss >> first_word >> second_word >> third_word;

        // Verificar si el primer comando es la acción o el nombre de la imagen
        std::string action;
        std::string image_name;
        bool inverted = false;

        // Si el formato es del tipo "im1 = read <path>"
        if (second_word == "=") {
            action = "read";
            image_name = first_word;
            std::string path;
            ss >> path;

            if (action == "read" && !path.empty()) {
                std::cout << "Leyendo imagen: " << path << std::endl;
                images[image_name] = image::Image::readImage(path);
                if (images[image_name] != nullptr) {
                    std::cout << "Imagen cargada como " << image_name << std::endl;
                } else {
                    std::cout << "Error al cargar la imagen." << std::endl;
                }
            } else {
                std::cout << "Error en el comando de lectura: ruta no proporcionada o comando incorrecto." << std::endl;
            }
        } 
        // Mostrar imagen: show imX o imX show, esto debido a que tuve problemas del tipo orden inverso en escritura, lo cual no es correcto según el pdf de la tarea
        else if (second_word == "show" || first_word == "show") {
            if (second_word == "show") {
                image_name = first_word;
            } else {
                image_name = second_word;
            }

            if (images.find(image_name) != images.end()) {
                images[image_name]->show();
            } else {
                std::cout << "Imagen no encontrada: " << image_name << std::endl;
            }
        } 
        // Obtener regiones: getregions imX o imX getregions
        else if (second_word == "getregions" || first_word == "getregions") {
            if (second_word == "getregions") {
                image_name = first_word;
            } else {
                image_name = second_word;
            }

            if (images.find(image_name) != images.end()) {
                auto regions = images[image_name]->getRegions();
                std::cout << "La imagen " << image_name << " tiene " << regions.size() << " regiones." << std::endl;
                int region_num = 1;
                for (const auto& region : regions) {
                    std::cout << "Región " << region_num++ << " -> size " << region.size << std::endl;
                }
            } else {
                std::cout << "Imagen no encontrada: " << image_name << std::endl;
            }
        } 
        // Mostrar una región específica: showregion imX N o imX showregion N
        else if (second_word == "showregion" || first_word == "showregion") {
            int region_id;
            if (second_word == "showregion") {
                image_name = first_word;
                ss >> region_id;
            } else {
                image_name = second_word;
                region_id = std::stoi(third_word);
            }

            if (images.find(image_name) != images.end()) {
                auto regions = images[image_name]->getRegions();
                if (region_id > 0 && region_id <= regions.size()) {
                    int current_id = 1;
                    for (const auto& region : regions) {
                        if (current_id == region_id) {
                            region.showRegion(images[image_name]->getWidth(), images[image_name]->getHeight());
                            break;
                        }
                        current_id++;
                    }
                } else {
                    std::cout << "ID de región no válido: " << region_id << std::endl;
                }
            } else {
                std::cout << "Imagen no encontrada: " << image_name << std::endl;
            }
        } 
        else {
            std::cout << "Comando no reconocido." << std::endl;
        }
    }

    // Liberar memoria
    for (auto& entry : images) {
        delete entry.second;
    }

    return 0;
}
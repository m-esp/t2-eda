#ifndef IO_IO_HPP
#define IO_IO_HPP
#include <iostream>

namespace io {
	void readTextFile(const std::string &filename);
}

#endif

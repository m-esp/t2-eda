/* implementation of the class Region
 */
#include <iostream>

void funcion(int* &p, int n){
	p = new int[n];
	for (int i = 0; i<n; i++){
		p[i] = i;
	}
}
int main(int args, char** vargs){
//	int A[10];
//	int B[10];
//	int D[10];
//	int* C = new int[10];
//	int* H = new int[10];
//	std::cout<< "A = " << A << std::endl;
//	std::cout<< "B = " << B << std::endl;
//	std::cout<< "C = " << C << std::endl;
//	std::cout<< "D = " << D << std::endl;
//	std::cout<< "H = " << H << std::endl;

	int *a  = nullptr;
	int n = 5;
	funcion(a, n);
	for (int i = 0; i<n; i++){
		std::cout<< a[i] << std::endl;
	}

	return 0;

//	int* intPtr = nullptr;
//	int  varA = 10;
//	intPtr = &varA;
//	std::cout<<intPtr<<std::endl;
//	std::cout<<&intPtr<<std::endl;
//	std::cout<<*intPtr<<std::endl;
//	std::cout<<&varA<<std::endl;
//	int* array = new int[5];
//	*array = 100;
//	*(array +1) = 10;
//	*(array +2) = 20;
//	*(array +3) = 30;
//	*(array +4) = 40;
//	int* p = array + 3;
//	std::cout << *(p - 3) << std::endl;
//	int* x = new int;
//	*x = 12;
//	std::cout<<*x<<std::endl;
//	return 0;
}

#include "image/image.hpp"
#include "image/region.hpp"
#include <fstream>
#include <iostream>
#include <cassert>
#include <cstring>
#include <vector>
#include <queue>
#include <list>
#include <utility> 

namespace image{

    Image::Image(): width(0), height(0), th_value(120), data(nullptr){

    }

    Image::Image(int w, int h): width(w), height(h), th_value(120),  data(nullptr){

    }

    Image::Image(int w, int h, uchar* _data): width(w), height(h), th_value(120), data(_data){
       threshold();
    }

    void Image::threshold(){
        if (data != nullptr) {
            for(int i = 0; i < height*width; i++){            
                if (static_cast<int>(data[i]) < th_value){
                    data[i] = static_cast<char>(0);
                }
                else{
                    data[i] = static_cast<char>(1);                    
                }
            }
        }
    }

    int Image::getValue(int row, int col){
        int pos = row*width + col;
        return static_cast<int>(data[pos]);
    }

    void Image::show() {
    std::cout << "----------------------" << std::endl;
    std::cout << "size [ (w: " << width << ") x   ( h:" << height << ")]" <<  std::endl;        
    std::cout << "---------------------" << std::endl;
    for(int i = 0 ; i < height ; i++ ) {
        for(int j = 0; j < width; j++ ) {
            if (getValue(i,j) == 0) {
                std::cout << "0";  
            }
            else {
                std::cout << "1";  
            }
        }
        std::cout << std::endl;
    }
}


    Image::~Image(){

    }

    Image* Image::readImage(std::string &path) {

    Image* im = nullptr;
    std::ifstream fin(path, std::ios::binary);
    
    if (!fin) {
        std::cerr << "Error al abrir el archivo: " << path << std::endl;
        return nullptr;
    }

    char info[54];
    // leer el header de 54 bytes
    fin.read(info, 54);

    // verificar si se pudo leer el header correctamente
    if (!fin) {
        std::cerr << "Error al leer el encabezado del archivo." << std::endl;
        return nullptr;
    }

    // extraer altura y ancho
    int width = *(int*)&info[18];
    int height = *(int*)&info[22];

    // verificar que las dimensiones sean válidas
    if (width <= 0 || height <= 0) {
        std::cerr << "Dimensiones no válidas: ancho = " << width << ", alto = " << height << std::endl;
        return nullptr;
    }

    // verificar el formato del archivo BMP
    if (info[0] != 'B' || info[1] != 'M') {
        std::cerr << "El archivo no es un archivo BMP válido." << std::endl;
        return nullptr;
    }

    int imagesize = *(int*)&info[34];
    if (imagesize == 0) imagesize = width * height;

    // leer los valores de los pixeles
    std::vector<char> buffer(imagesize);
    fin.read(buffer.data(), imagesize);

    if (!fin) {
        std::cerr << "Error al leer los datos de imagen." << std::endl;
        return nullptr;
    }

    fin.close();

    // copiar los datos de manera ordenada
    uchar* ordered_data = new uchar[imagesize];
    for (int i = 0; i < height; ++i) {
        std::memcpy(ordered_data + width * i, buffer.data() + width * (height - 1 - i), width);
    }

    im = new Image(width, height, ordered_data);
    return im;
}

    std::list<Region> Image::getRegions() {
        std::list<Region> regions;  // Lista para almacenar las regiones
        bool* visited = new bool[width * height]();  // Array para verificar si el píxel ya fue visitado

        int region_id = 1;  // Identificador único para cada región

        // Recorrer cada píxel de la imagen
        for (int row = 0; row < height; ++row) {
            for (int col = 0; col < width; ++col) {
                int pos = row * width + col;
                
                // Si el píxel es 1 y no ha sido visitado
                if (data[pos] == 1 && !visited[pos]) {
                    // Iniciar nueva región
                    Region region;
                    region.id = region_id++;
                    region.size = 0;

                    // Usar un algoritmo tipo BFS (recorrido en anchura) para llenar la región
                    std::queue<std::pair<int, int>> q;
                    q.push({row, col});
                    visited[pos] = true;

                    while (!q.empty()) {
                        auto [r, c] = q.front(); q.pop();
                        region.size++;
                        region.points.push_back({r, c});  // Agregar el punto a la lista de la región

                        // Explorar las 4 direcciones (arriba, abajo, izquierda, derecha)
                        std::vector<std::pair<int, int>> directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
                        for (auto [dr, dc] : directions) {
                            int new_r = r + dr;
                            int new_c = c + dc;
                            int new_pos = new_r * width + new_c;

                            // Verificar que esté dentro de los límites y que no haya sido visitado
                            if (new_r >= 0 && new_r < height && new_c >= 0 && new_c < width && 
                                data[new_pos] == 1 && !visited[new_pos]) {
                                q.push({new_r, new_c});
                                visited[new_pos] = true;
                            }
                        }
                    }

                    regions.push_back(region);  // Agregar la región a la lista de regiones
                }
            }
        }

        delete[] visited;
        return regions;
    }
}

#include <list>
#include <string>
#include "region.hpp"

typedef unsigned char uchar;

namespace image {
    class Image {
    private:
        int width;
        int height;
        int th_value;
        uchar* data;

    public:
        Image();
        Image(int w, int h);
        Image(int w, int h, uchar* _data);
        void threshold();
        int getValue(int row, int col);
        void show();
        std::list<Region> getRegions();  
        int getWidth() const { return width; }   
        int getHeight() const { return height; } 
        virtual ~Image(); 
        static Image* readImage(std::string &path);        
    };
}
